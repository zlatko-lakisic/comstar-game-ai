# YOLOX RTW Claude handoff archive

See `docs/yolox-rtw-claude-handoff.md` in the repo for the full narrative.

## Contents

- `eval/` — live CV (green) vs YOLO (orange) annotated grabs
- `hue_learn/` — capital_zoom Rome frame, rim hits, learned_bands.json
- `coco_val_sample/` — instances_val2017.json + 12 settlement-positive val JPEGs
- `weights/yolox_rtw_nano.onnx` (+ .sha256)
- `auto_label_summary.json` — final dataset counts
- `cv_unit_fixture/` — OpenCV unit-test reference frame (if included)

## Quick checks

```text
python scripts/detection/eval_settlement_yolo_vs_cv.py --fixture <jpg> --onnx weights/yolox_rtw_nano.onnx --input-size 640
python scripts/detection/offline_val_check.py --onnx weights/yolox_rtw_nano.onnx --image <jpg> --input-size 640
```
